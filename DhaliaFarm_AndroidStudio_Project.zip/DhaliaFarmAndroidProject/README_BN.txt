DHALIA FARM MANAGER — Android project source

এই ZIP-এ Android Studio-তে APK বানানোর সম্পূর্ণ source project এবং উন্নত HTML app আছে।
এখানে তৈরি APK ফাইল নেই। বর্তমান কাজের পরিবেশে Android SDK/Gradle build tools নেই এবং নেটওয়ার্ক বন্ধ, তাই সরাসরি APK compile করা সম্ভব হয়নি।

APK বানানোর ধাপ:
1) Android Studio ইনস্টল করে ZIP extract করুন।
2) Android Studio > Open > DhaliaFarmAndroidProject ফোল্ডার নির্বাচন করুন।
3) Gradle sync শেষ হতে দিন (Android SDK Platform 35 লাগবে)।
4) Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
5) app/build/outputs/apk/debug/app-debug.apk ফাইল ফোনে পাঠিয়ে install করুন।

অ্যাপের ডেটা ফোনের WebView local storage-এ থাকে। ফোন বদলানোর আগে Partner ট্যাব থেকে ডেটা ব্যাকআপ নিন।

নোট: ডোজ ক্যালকুলেটর শুধু গাণিতিক হিসাব; পশু চিকিৎসকের নির্ধারিত dose ছাড়া ওষুধ প্রয়োগ করবেন না।
